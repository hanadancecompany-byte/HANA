HANA — ABOUT PAGE (PAGE 02)

Files:
- about.html
- style.css
- script.js

HOW TO USE
1. Keep these three files together in the same folder.
2. Open about.html in a browser to preview.
3. When the complete HANA website is assembled, this page should be named about.html and linked from the main navigation.

DESIGN NOTES
- Uses HANA's approved website palette: plum, purple, lavender, ivory and champagne.
- Responsive layout for mobile and desktop.
- The Founder portrait area is intentionally a designed placeholder, not a real photograph. Replace it with a professional founder portrait when one is ready.
- Navigation links to the planned HANA pages; pages other than Home and About will work once those pages are added to the final website.

CONTENT NOTES
- Founder experience and project figures are presented as supplied/approved.
- The 500+ figure is presented as performances, and 250+ as performers involved in large-scale productions.
- Verify all figures before publishing.
